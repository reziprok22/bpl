from django.urls import path

from . import views

urlpatterns = [
    path('app_bplengg/', views.index, name='index'),
]
