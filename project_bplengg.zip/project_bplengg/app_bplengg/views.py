from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.

def index(request):
    kontaktdaten = {    'email':'gruezi@bauphysiklengg.ch',
                        'telefon':'+41 61 508 59 09',
                        'firmenname': 'Bauphysik Lengg',
                        'domizilname': 'c/o BYRO',
                        'domizilstrasse': 'Rathausgasse 6-8',
                        'domizilplz': '5000 Aarau'
                    }
    context = {'kontaktdaten':kontaktdaten}

    return render(request, 'app_bplengg/index.html', context)
